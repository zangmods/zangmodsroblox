return { -- lucide
    Tab         = "table-of-contents",
    Paragraph   = "type",
    Button      = "square-mouse-pointer",
    Toggle      = "toggle-right",
    Slider      = "sliders-horizontal",
    Keybind     = "command",
    Input       = "text-cursor-input",
    Dropdown    = "chevrons-up-down",
    Code        = "terminal",
    Colorpicker = "palette",
}